import PerformanceReview from "../models/PerformanceReview.js";
import Employee from "../models/Employee.js";

// CREATE Performance Review
export const createReview = async (req, res) => {
  try {
    // 1. Relational Integrity Check: Verify if the target employee exists
    const employeeExists = await Employee.findById(req.body.employeeId);
    if (!employeeExists) {
      return res.status(404).json({
        success: false,
        message: "Target Employee ID does not exist"
      });
    }

    // 2. Proactively check if a review already exists for this employee 
    // (This prevents ugly MongoDB duplicate key index errors from crashing cleanly)
    const reviewExists = await PerformanceReview.findOne({ employeeId: req.body.employeeId });
    if (reviewExists) {
      return res.status(400).json({
        success: false,
        message: "A performance review record already exists for this employee (Strict 1-to-1 Violation)"
      });
    }

    const review = await PerformanceReview.create(req.body);

    res.status(201).json({
      success: true,
      data: review
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
};

// GET All Performance Reviews
export const getReviews = async (req, res) => {
  try {
    // Automatically populate the basic employee details when pulling reviews
    const reviews = await PerformanceReview.find().populate("employeeId", "name email");

    res.status(200).json({
      success: true,
      count: reviews.length,
      data: reviews
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// GET Single Performance Review by ID
export const getReviewById = async (req, res) => {
  try {
    const review = await PerformanceReview.findById(req.params.id).populate("employeeId", "name email");

    if (!review) {
      return res.status(404).json({
        success: false,
        message: "Performance review record not found"
      });
    }

    res.status(200).json({
      success: true,
      data: review
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// UPDATE Performance Review
export const updateReview = async (req, res) => {
  try {
    const review = await PerformanceReview.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!review) {
      return res.status(404).json({
        success: false,
        message: "Performance review record not found"
      });
    }

    res.status(200).json({
      success: true,
      data: review
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// DELETE Performance Review
export const deleteReview = async (req, res) => {
  try {
    const review = await PerformanceReview.findByIdAndDelete(req.params.id);

    if (!review) {
      return res.status(404).json({
        success: false,
        message: "Performance review record not found"
      });
    }

    res.status(200).json({
      success: true,
      message: "Performance review record deleted successfully"
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};