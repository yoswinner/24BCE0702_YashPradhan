import Employee from "../models/Employee.js";
import Project from "../models/Project.js";
import PerformanceReview from "../models/PerformanceReview.js";

// 1. GET Department Workforce & Salary Metrics
// @route   GET /api/analytics/departments
export const getDepartmentMetrics = async (req, res) => {
  try {
    const metrics = await Employee.aggregate([
      // Stage A: Join with Departments collection to get the department name
      {
        $lookup: {
          from: "departments",
          localField: "departmentId",
          foreignField: "_id",
          as: "departmentDetails"
        }
      },
      // Stage B: Flatten the joined department details array
      { $unwind: "$departmentDetails" },
      // Stage C: Group by department and calculate analytics metrics
      {
        $group: {
          _id: "$departmentId",
          departmentName: { $first: "$departmentDetails.departmentName" },
          totalEmployees: { $sum: 1 },
          averageSalary: { $avg: "$salary" },
          highestSalary: { $max: "$salary" }
        }
      },
      // Stage D: Sort alphabetically by department name
      { $sort: { departmentName: 1 } }
    ]);

    res.status(200).json({
      success: true,
      count: metrics.length,
      data: metrics
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// 2. GET Project Allocation & Workforce Utilization Report
// @route   GET /api/analytics/projects/utilization
export const getProjectUtilization = async (req, res) => {
  try {
    const report = await Project.aggregate([
      // Stage A: Join with the Employees collection to look up details of assigned staff
      {
        $lookup: {
          from: "employees",
          localField: "employeeIds",
          foreignField: "_id",
          as: "assignedStaff"
        }
      },
      // Stage B: Restructure the output to show clean, calculated parameters
      {
        $project: {
          projectName: 1,
          budget: 1,
          totalAllocatedStaff: { $size: "$employeeIds" },
          // Pull out just names and emails from the joined array
          staffList: {
            $map: {
              input: "$assignedStaff",
              as: "staff",
              in: { name: "$$staff.name", email: "$$staff.email" }
            }
          }
        }
      }
    ]);

    res.status(200).json({
      success: true,
      count: report.length,
      data: report
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// 3. GET Top Performers Insights (High Ratings)
// @route   GET /api/analytics/performance/top
export const getTopPerformers = async (req, res) => {
  try {
    const topPerformers = await PerformanceReview.aggregate([
      // Stage A: Filter for high reviews (Rating of 4 or 5)
      { $match: { rating: { $gte: 4 } } },
      // Stage B: Join with Employees collection to grab performance details
      {
        $lookup: {
          from: "employees",
          localField: "employeeId",
          foreignField: "_id",
          as: "employeeDetails"
        }
      },
      // Stage C: Flatten the joined array
      { $unwind: "$employeeDetails" },
      // Stage D: Sort by rating in descending order (highest score first)
      { $sort: { rating: -1 } },
      // Stage E: Project clean fields for response layout
      {
        $project: {
          _id: 1,
          rating: 1,
          comments: 1,
          employeeName: "$employeeDetails.name",
          employeeEmail: "$employeeDetails.email"
        }
      }
    ]);

    res.status(200).json({
      success: true,
      count: topPerformers.length,
      data: topPerformers
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};