import mongoose from "mongoose";

// DROP Entire Collection Dynamically
export const dropCollection = async (req, res) => {
  try {
    const { collectionName } = req.params;
    
    // 1. Fetch a raw list of all existing collections in your current MongoDB database
    const collections = await mongoose.connection.db.listCollections().toArray();
    
    // 2. Check if the collection name provided by the client actually exists
    const collectionExists = collections.some(col => col.name === collectionName);

    if (!collectionExists) {
      return res.status(404).json({
        success: false,
        message: `Collection '${collectionName}' does not exist in the database`
      });
    }

    // 3. Drop the collection cleanly using the raw MongoDB driver wrapper
    await mongoose.connection.db.dropCollection(collectionName);

    res.status(200).json({
      success: true,
      message: `Collection '${collectionName}' was successfully dropped from the database`
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};