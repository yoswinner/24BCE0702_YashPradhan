import mongoose from 'mongoose';

const PerformanceReviewSchema = new mongoose.Schema({
  rating: {
    type: Number,
    required: [true, 'Rating is required'],
    min: [1, 'Rating must be at least 1'],
    max: [5, 'Rating cannot exceed 5']
  },
  comments: {
    type: String,
    required: [true, 'Review comments are required']
  },
  reviewDate: {
    type: Date,
    default: Date.now
  },
  // Relational link: Linked strictly to a single employee
  employeeId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Employee',
    required: [true, 'Review must be linked to a single employee'],
    unique: true // Guarantees a strict 1-to-1 relationship mapping in MongoDB
  }
}, { timestamps: true });

export default mongoose.model('PerformanceReview', PerformanceReviewSchema);