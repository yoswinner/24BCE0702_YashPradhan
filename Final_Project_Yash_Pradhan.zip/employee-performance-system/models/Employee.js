import mongoose from 'mongoose';

const EmployeeSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Employee name is required'],
    trim: true
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    match: [/.+\@.+\..+/, 'Please fill a valid email address']
  },
  salary: {
    type: Number,
    required: [true, 'Salary is required']
  },
  joiningDate: {
    type: Date,
    default: Date.now
  },
  // Relational link: Storing the ID of the Department this employee works in
  departmentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Department',
    required: [true, 'An employee must belong to a department']
  }
}, { timestamps: true });

export default mongoose.model('Employee', EmployeeSchema);