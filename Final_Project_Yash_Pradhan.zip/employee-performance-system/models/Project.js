import mongoose from 'mongoose';

const ProjectSchema = new mongoose.Schema({
  projectName: {
    type: String,
    required: [true, 'Project name is required'],
    trim: true
  },
  budget: {
    type: Number,
    required: [true, 'Project budget is required']
  },
  // Relational link: An array of ObjectIds pointing to multiple employees
  employeeIds: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Employee'
  }]
}, { timestamps: true });

export default mongoose.model('Project', ProjectSchema);