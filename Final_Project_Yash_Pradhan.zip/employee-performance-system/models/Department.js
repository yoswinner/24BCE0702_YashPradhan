import mongoose from 'mongoose';

const DepartmentSchema = new mongoose.Schema({
  departmentName: {
    type: String,
    required: [true, 'Department name is required'],
    unique: true,
    trim: true
  },
  budget: {
    type: Number,
    required: [true, 'Budget is required'],
    default: 0
  }
}, { timestamps: true });

export default mongoose.model('Department', DepartmentSchema);