import mongoose from "mongoose";
import dotenv from "dotenv";
import connectDB from "./config/db.js";

// Import all 4 models
import Department from "./models/Department.js";
import Employee from "./models/Employee.js";
import Project from "./models/Project.js";
import PerformanceReview from "./models/PerformanceReview.js";

dotenv.config();

// Connect to the database
connectDB();

const importData = async () => {
  try {
    // 1. Clear out all existing data to prevent duplicate key or strict 1-to-1 errors
    await Department.deleteMany();
    await Employee.deleteMany();
    await Project.deleteMany();
    await PerformanceReview.deleteMany();

    console.log("🗑️ Existing database collections cleared successfully.");

    // 2. Seed Departments
    const createdDepartments = await Department.insertMany([
      { departmentName: "Data Science", budget: 600000 },
      { departmentName: "Engineering", budget: 850000 },
      { departmentName: "Human Resources", budget: 250000 },
      { departmentName: "Marketing", budget: 300000 }
    ]);

    // Pull out specific department objects to use their dynamically generated ObjectIds
    const dataScienceId = createdDepartments[0]._id;
    const engineeringId = createdDepartments[1]._id;

    // 3. Seed Employees (Passing the real Department ObjectIds)
    const createdEmployees = await Employee.insertMany([
      {
        name: "Yash Pradhan",
        email: "yash@vitstudent.ac.in",
        salary: 95000,
        departmentId: dataScienceId
      },
      {
        name: "Anjini Sharma",
        email: "anjini@vitstudent.ac.in",
        salary: 88000,
        departmentId: dataScienceId
      },
      {
        name: "Alice Johnson",
        email: "alice@company.com",
        salary: 75000,
        departmentId: engineeringId
      },
      {
        name: "Bob Singh",
        email: "bob@company.com",
        salary: 90000,
        departmentId: engineeringId
      }
    ]);

    // Pull out specific employee IDs for project mappings and reviews
    const yashId = createdEmployees[0]._id;
    const anjiniId = createdEmployees[1]._id;
    const aliceId = createdEmployees[2]._id;

    // 4. Seed Projects (Many-to-Many Array Linkage)
    await Project.insertMany([
      {
        projectName: "Enterprise Analytics Dashboard",
        budget: 250000,
        employeeIds: [yashId, anjiniId] // Both Yash and Anjini assigned
      },
      {
        projectName: "Core Database Overhaul",
        budget: 400000,
        employeeIds: [yashId, aliceId] // Both Yash and Alice assigned
      }
    ]);

    // 5. Seed Performance Reviews (Strict One-to-One Linkage)
    await PerformanceReview.insertMany([
      {
        rating: 5,
        comments: "Exceptional system architectural design and rigorous backend testing skills.",
        employeeId: yashId
      },
      {
        rating: 5,
        comments: "Outstanding collaborative work on cross-functional full-stack implementations.",
        employeeId: anjiniId
      }
    ]);

    console.log("🚀 Custom relational enterprise data successfully seeded into MongoDB!");
    process.exit(0); // Exit the process cleanly
  } catch (error) {
    console.error(`❌ Data Import Failure: ${error.message}`);
    process.exit(1); // Exit with failure code
  }
};

const destroyData = async () => {
  try {
    await Department.deleteMany();
    await Employee.deleteMany();
    await Project.deleteMany();
    await PerformanceReview.deleteMany();

    console.log("🗑️ All data successfully destroyed!");
    process.exit(0);
  } catch (error) {
    console.error(`❌ Data Destruction Failure: ${error.message}`);
    process.exit(1);
  }
};

// Check the terminal command flags to decide whether to import or destroy data
if (process.argv[2] === "-d") {
  destroyData();
} else {
  importData();
}