import express from "express";
import { dropCollection } from "../controllers/adminController.js";

const router = express.Router();

// Delete endpoint pointing to a dynamic route parameter (:collectionName)
router.delete("/drop/:collectionName", dropCollection);

export default router;