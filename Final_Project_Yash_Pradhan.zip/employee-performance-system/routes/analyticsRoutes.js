import express from "express";
import {
  getDepartmentMetrics,
  getProjectUtilization,
  getTopPerformers
} from "../controllers/analyticsController.js";

const router = express.Router();

router.get("/departments", getDepartmentMetrics);
router.get("/projects/utilization", getProjectUtilization);
router.get("/performance/top", getTopPerformers);

export default router;