import express from "express";
import Joi from "joi";
import validateRequest from "../middleware/validationMiddleware.js";
import {
  createEmployee,
  getEmployees,
  getEmployeeById,
  updateEmployee,
  deleteEmployee
} from "../controllers/employeeController.js";

const router = express.Router();

// 1. Schema for CREATING an employee (All fields strictly required)
const employeeCreateSchema = Joi.object({
  name: Joi.string().min(2).max(50).required().messages({
    "string.empty": "Employee name cannot be blank",
    "any.required": "Employee name is required"
  }),
  email: Joi.string().email().required().messages({
    "string.email": "Please provide a valid email format (e.g., name@company.com)",
    "any.required": "Email address is required"
  }),
  salary: Joi.number().min(0).required().messages({
    "number.min": "Salary allocation cannot be a negative value"
  }),
  departmentId: Joi.string().hex().length(24).required().messages({
    "string.length": "Department ID must be a valid 24-character hexadecimal string",
    "any.required": "Department reference ID is required"
  })
});

// 2. Schema for UPDATING an employee (All fields optional so you can update just one thing)
const employeeUpdateSchema = Joi.object({
  name: Joi.string().min(2).max(50).messages({
    "string.empty": "Employee name cannot be blank"
  }),
  email: Joi.string().email().messages({
    "string.email": "Please provide a valid email format (e.g., name@company.com)"
  }),
  salary: Joi.number().min(0).messages({
    "number.min": "Salary allocation cannot be a negative value"
  }),
  departmentId: Joi.string().hex().length(24).messages({
    "string.length": "Department ID must be a valid 24-character hexadecimal string"
  })
});

// 3. Inject the correct validation guards into the paths
router.post("/", validateRequest(employeeCreateSchema), createEmployee);
router.get("/", getEmployees);
router.get("/:id", getEmployeeById);
router.put("/:id", validateRequest(employeeUpdateSchema), updateEmployee);
router.delete("/:id", deleteEmployee);

export default router;