import express from "express";
import Joi from "joi";
import validateRequest from "../middleware/validationMiddleware.js";
import {
  createDepartment,
  getDepartments,
  getDepartmentById,
  updateDepartment,
  deleteDepartment
} from "../controllers/departmentController.js";

const router = express.Router();

// 1. Define the Joi rules for a Department
const departmentValidationSchema = Joi.object({
  departmentName: Joi.string().min(2).max(50).required().messages({
    "string.empty": "Department name cannot be blank",
    "any.required": "Department name is a required field"
  }),
  budget: Joi.number().min(0).required().messages({
    "number.min": "Budget cannot be a negative value"
  })
});

// 2. Inject the validator right before the createDepartment controller runs!
router.post("/", validateRequest(departmentValidationSchema), createDepartment);

router.get("/", getDepartments);
router.get("/:id", getDepartmentById);
router.put("/:id", updateDepartment);
router.delete("/:id", deleteDepartment);

export default router;