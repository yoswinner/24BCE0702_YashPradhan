# Headless Enterprise Workforce & Performance System

An advanced, headless RESTful backend engine engineered using modern **Node.js (ES Modules)**, **Express**, and **MongoDB/Mongoose**. This system showcases enterprise-level design patterns, including relational database constraints (One-to-One, One-to-Many, Many-to-Many), request-filtering data validation layers, native multi-stage aggregation pipelines, and custom global error isolation middleware.

---

## 🏗️ Architectural Core Features

* **Relational Schema Integrity:** Implements rigorous cross-collection document mapping using native MongoDB ObjectIds:
    * **One-to-Many ($1 \rightarrow N$):** Departments to Employees linkage.
    * **Many-to-Many ($N \rightarrow M$):** Projects to Employees array mapping.
    * **Strict One-to-One ($1 \rightarrow 1$):** Isolated individual performance reviews enforced via application-level check locks.
* **HTTP Ingress Filtering (Joi Validation):** Intercepts incoming client request payloads at the router boundary, blocking invalid data structures, malformed types, or negative numeric parameters before they reach database threads.
* **Advanced Analytics Aggregation Engine:** Replaces basic query engines with high-performance, multi-stage native MongoDB pipelines (`$lookup`, `$group`, `$unwind`, `$project`, `$map`) to compute corporate analytics on the fly.
* **Global Exception & Fault Isolation Middleware:** Normalizes backend exceptions, intercepting 404 routes and converting lower-level database anomalies (such as Mongoose casting errors) into structured, client-safe JSON formats.
* **Administrative Access Layer:** Features a controlled dynamic execution path to target and drop active database tables programmatically using raw MongoDB collection driver methods.
* **Interactive Specification Sandbox:** Features live browser-accessible Swagger UI API layout documentation mounted straight to the development framework thread.

---

## 📂 System Directory Structure

employee-performance-system/
├── config/
│   └── db.js
├── controllers/
│   ├── adminController.js
│   ├── analyticsController.js
│   ├── departmentController.js
│   ├── employeeController.js
│   ├── performanceReviewController.js
│   └── projectController.js
├── middleware/
│   ├── errorMiddleware.js
│   └── validationMiddleware.js
├── models/
│   ├── Department.js
│   ├── Employee.js
│   ├── PerformanceReview.js
│   └── Project.js
├── routes/
│   ├── adminRoutes.js
│   ├── analyticsRoutes.js
│   ├── departmentRoutes.js
│   ├── employeeRoutes.js
│   ├── performanceReviewRoutes.js
│   └── projectRoutes.js
├── .env
├── package.json
├── seeder.js
├── server.js
└── swagger.json

---

## 🛠️ Technology Stack & Dependencies

* **Runtime Environment:** Node.js (v24+)
* **Backend Framework:** Express.js
* **Database Object Modeling:** Mongoose / MongoDB Atlas
* **Data Validation:** Joi
* **Interactive Documentation:** Swagger UI Express

---

## 🚀 Quick-Start Installation & Setup

### 1. Clone & Install Dependencies
Navigate to your project directory and pull down required packages from the node package manager:
npm install

### 2. Configure Environment Variables
Create a file named `.env` in the root folder of your project workspace and populate it with your local runtime parameters:
PORT=5000
MONGO_URI=your_mongodb_atlas_connection_string
NODE_ENV=development

### 3. Seed the Database Engine
Execute the automated data-seeding pipeline script to completely clear the target database instance and inject a perfectly mapped, unified relational corporate test dataset instantly:
npm run data:import

### 4. Fire Up the Development Server
Boot up the backend instance with live automatic reload monitoring enabled:
npm run dev

---

## 🗺️ Complete API Endpoint Mapping Directory

### 🟢 1. Core Relational Entities (CRUD Routing)

| Module / System | HTTP Method | Endpoint Target Path | Functionality & Relational Execution Model |
| :--- | :---: | :--- | :--- |
| **Departments** | POST | /api/departments | Creates a new corporate branch department. *Validated via Joi.* |
| | GET | /api/departments | Fetches all active department records. |
| | GET | /api/departments/:id | Fetches a single specific department document. |
| | PUT | /api/departments/:id | Modifies department fields (e.g., budgets). |
| | DELETE | /api/departments/:id | Drops an individual department branch record. |
| **Employees** | POST | /api/employees | Creates a staff record linked to a Department ID. *Requires valid Hex-24 ObjectId.* |
| | GET | /api/employees | Returns all employees. **Auto-populates mapped Department Name.** |
| | GET | /api/employees/:id | Fetches single employee document. |
| | PUT | /api/employees/:id | Updates fields. *Injects partial payload validation layers.* |
| | DELETE | /api/employees/:id | Deletes individual employee record. |
| **Projects** | POST | /api/projects | Instantiates a project document holding an array of assigned Employee ObjectIds. |
| | GET | /api/projects | Returns all projects. **Resolves Many-to-Many employee array mapping.** |
| | GET | /api/projects/:id | Fetches a specific project with its full list of assigned staff. |
| | PUT | /api/projects/:id | Updates project details or modifies assigned workforce lists. |
| | DELETE | /api/projects/:id | Drops the designated project document cleanly. |
| **Reviews** | POST | /api/reviews | Instantiates a performance review card. **Blocks duplicates to enforce strict 1-to-1 bounds.** |
| | GET | /api/reviews | Fetches all reviews, auto-stitching core target Employee metrics. |
| | PUT | /api/reviews/:id | Modifies active ratings or analytical performance comment logs. |
| | DELETE | /api/reviews/:id | Drops the active review document from the collection. |

### 📊 2. Advanced Multi-Stage Analytics Engine

| HTTP Method | Endpoint Target Path | Native MongoDB Processing Steps & Output Analytics |
| :---: | :--- | :--- |
| GET | /api/analytics/departments | Pipelines an automated lookup joining staff to departments, calculating total headcount, average pay bands, and peak salary ranges per module on the fly. |
| GET | /api/analytics/projects/utilization | Aggregates the project database collection, running sizing calculations on nested personnel arrays to monitor workforce utilization efficiency profiles. |
| GET | /api/analytics/performance/top | Filters reviews for scores >= 4, running structural lookups to output a descending high-performer leaderboard matched directly with names and emails. |

### 🛠️ 3. Administrative Actions & Testing Sandbox

| HTTP Method | Endpoint Target Path | Functionality Description |
| :---: | :--- | :--- |
| DELETE | /api/admin/drop/:collectionName | Safely evaluates runtime metadata checks to check existence before dropping a collection via raw database connection hooks. |
| GET | /api-docs | Renders the complete, interactive browser-hosted Swagger UI API schema sandbox dashboard. |

---

> ### 💡 Evaluation Note
> To prove the strength of the system boundary, hit `POST /api/employees` with bad parameter objects or target `GET /api/employees/abc123invalidid` using malformed routing keys in Postman. The custom middleware layers will seamlessly intercept the execution path and return a standardized, clean JSON error payload instead of a runtime application crash log.