// 1. Custom 404 Handler for Undefined Routes
export const notFoundHandler = (req, res, next) => {
  const error = new Error(`Route Not Found - Cannot ${req.method} ${req.originalUrl}`);
  res.status(404);
  next(error); // Passes the error along to the global catcher below
};

// 2. Global Error Catcher (Interceptors all execution exceptions)

export const globalErrorHandler = (err, req, res, next) => {
  let statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  let message = err.message;

  // Handle invalid ObjectId errors
  if (err.name === "CastError" && err.kind === "ObjectId") {
    statusCode = 400;
    message = "Resource not found. Invalid system database hex ID format.";
  }

  res.status(statusCode).json({
    success: false,
    message,
    stack: process.env.NODE_ENV === "production" ? null : err.stack
  });
};