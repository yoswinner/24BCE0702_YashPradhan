// A generic middleware constructor that validates the incoming req.body against a Joi schema
const validateRequest = (schema) => {
  return (req, res, next) => {
    const { error } = schema.validate(req.body, { abortEarly: false }); // abortEarly: false catches ALL errors, not just the first one
    
    if (error) {
      // Collect all validation errors into a clean array message
      const errorMessages = error.details.map((detail) => detail.message);
      return res.status(400).json({
        success: false,
        message: "Validation Error",
        errors: errorMessages
      });
    }
    
    next(); // If data is perfect, pass control to the controller
  };
};

export default validateRequest;